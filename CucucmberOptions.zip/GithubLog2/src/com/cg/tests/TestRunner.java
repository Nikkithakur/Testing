package com.cg.tests;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		plugin = {"pretty","html:HTMLFolderName/cucumber.html",},
		features= {"features"},  
		glue= {"com.cg.github.stepdefinitions"} ,
		dryRun=false,strict=false,monochrome=false,
		tags= "@sanity,@regression"
		
		)
/*
1.format deprecated, plugin is used instead, pretty is for displaying scenarios on console
	html:HTMLFolderName/cucumber.html
	json:HTMLFolderName/cucumber.json --> for showing scenarios, runtime exceptions like closing
	window while continuing operation and all
	below one's are profiles
2.features={"feature folder path till parent"}
3.glue={"step definition path"}
4. dryrun="true" --> all testcases will be skipped
5. strict="false" --> steps with step definition will be executed. without definition will be skipped
	strict="true" -->steps with step definition will be executed, remaining errors
6.monochrome="true"--> console output will be in same color
7. tags="@ ,@ " --> written above scenarios to tell which scenarios have to be executed

@Before @After--> hooks 
*/
public class TestRunner {

}
